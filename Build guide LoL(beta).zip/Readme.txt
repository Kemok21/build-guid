﻿Build guide LoL
Version 1.0
Kilankemok
© 2017


Build guide LoL help:

 ► The program is designed to create files-guides for League of Legends.

 ► The program receives a list of guides from the site http://www.mobafire.com.

 ► To view the list of guides, enter name of the champion in text field,
   then press enter or "Show guides" button.
   A list of guides for the given champion will appear in field below.

 ► To view the guide, You need to click on the "show guide" button.
   A list of items included in this guide appears in the field.

 ► To export the selected guide to a file, click the "Export to file" button.

 ► To get the file-guide in the required directory
   (...\League of Legends\Config\Champions\{champion}\Recommended\),
   You need to specify the path to the League of Legends in [settings->path].
   By default, the file-guide is saved in the program directory.

 ► To update data on subjects and champions, you need to use the option
   [Settings-> Update Data].

 ► The buttons "ru_RU" and "en_US" mean the localization of queries
   for object names, Russian and English respectively.

 ► After the first start, the program creates a setting file.



Справка Build guide LoL:

 ► Программа предназначена для создания файлов-гайдов для League of Legends.

 ► Программа получает список гайдов с сайта http://www.mobafire.com.

 ► Чтобы посмотреть список гайдов, в текстовом поле нужно ввести имя чемпиона,
   затем нажать ввод или кнопку "Показать гайды".
   В поле ниже появится список гайдов на заданного чемпиона.

 ► Чтобы посмотреть гайд, нужно нажать на кнопку "Показать гайд".
   В поле появится список предметов входящие в этот гайд.

 ► Чтобы экспортировать выбранный гайд в файл, нужно нажать кнопку
   "Экспорт в файл".

 ► Для того чтобы файл-гайд оказался в нужной директории
   (...\League of Legends\Config\Champions\{champion}\Recommended\),
   нужно в [Настройки->Путь к LoL] указать путь к папке League of Legends.
   По умолчанию файл-гайд сохраняется в директорию программы.

 ► Для обновления данных по предметам и чемпионам нужно использовать опцию
   [Настройки->Обновление данных].

 ► Кнопки "ru_RU" и "en_US", означают локализацию запросов на имена предметов,
   Русская и Английская соответственно.

 ► После первого запуска, программа создает файл настроек.


E-mail: kilankemok@gmail.com'


